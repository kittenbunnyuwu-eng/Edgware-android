package com.example.edgewaredroid

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.drawable.AnimatedImageDrawable
import android.media.AudioAttributes
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.io.File
import java.util.concurrent.Executors
import kotlin.random.Random

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "com.example.edgewaredroid.START"
        const val ACTION_STOP = "com.example.edgewaredroid.STOP"
        const val ACTION_CLEAR = "com.example.edgewaredroid.CLEAR"
        private const val CHANNEL = "overlay"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var wm: WindowManager
    private val popups = mutableListOf<View>()
    private val players = mutableListOf<MediaPlayer>()

    private var imgs = emptyList<File>()
    private var vids = emptyList<File>()
    private var auds = emptyList<File>()
    private var caps = emptyList<String>()

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                spawn()
            } catch (_: Exception) {
            }
            val base = Prefs.int(this@OverlayService, "interval") * 1000L
            val next = (base * (0.6 + Random.nextDouble() * 0.8)).toLong().coerceAtLeast(800L)
            handler.postDelayed(this, next)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_CLEAR -> { clearAll(); return START_NOT_STICKY }
        }
        startForegroundCompat()
        if (running) return START_NOT_STICKY

        val pack = Prefs.pack(this)?.let { PackManager.load(this, it) }
        if (pack == null) {
            Toast.makeText(this, "Aucun pack sélectionné", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        imgs = pack.files("img")
        vids = pack.files("vid")
        auds = pack.files("aud")
        caps = pack.captions
        running = true
        handler.postDelayed(tick, 1500)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        clearAll()
        executor.shutdownNow()
        super.onDestroy()
    }

    // ---------- Notification ----------

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Popups", NotificationManager.IMPORTANCE_LOW)
        )
        fun action(a: String, code: Int) = PendingIntent.getService(
            this, code, Intent(this, OverlayService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Popups actifs")
            .setContentText("Appuie sur « Arrêter » pour tout couper")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Arrêter", action(ACTION_STOP, 1))
            .addAction(0, "Tout fermer", action(ACTION_CLEAR, 2))
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    // ---------- Génération des popups ----------

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun popupWidth(): Int =
        (resources.displayMetrics.widthPixels * Prefs.int(this, "size") / 100f)
            .toInt().coerceAtLeast(dp(120))

    private fun caption(): String? =
        if (Prefs.bool(this, "cap") && caps.isNotEmpty()) caps.random() else null

    private fun spawn() {
        if (popups.size >= Prefs.int(this, "max")) return
        val kinds = mutableListOf<String>()
        if (Prefs.bool(this, "img") && imgs.isNotEmpty()) kinds += "img"
        if (Prefs.bool(this, "vid") && vids.isNotEmpty()) kinds += "vid"
        if (Prefs.bool(this, "aud") && auds.isNotEmpty()) kinds += "aud"
        if (Prefs.bool(this, "txt") && caps.isNotEmpty()) kinds += "txt"
        if (kinds.isEmpty()) return
        when (kinds.random()) {
            "img" -> spawnImage(imgs.random())
            "vid" -> spawnVideo(vids.random())
            "aud" -> playAudio(auds.random())
            "txt" -> showPopup(null, 0, caps.random(), Prefs.int(this, "duration") * 1000L)
        }
    }

    private fun spawnImage(f: File) {
        val widthPx = popupWidth()
        executor.execute {
            try {
                var ratio = 1f
                val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    ratio = h.toFloat() / w
                    if (w > widthPx) {
                        dec.setTargetSize(widthPx, (h * widthPx.toFloat() / w).toInt().coerceAtLeast(1))
                    }
                }
                handler.post {
                    if (!running) return@post
                    val iv = ImageView(this)
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    iv.setImageDrawable(d)
                    if (d is AnimatedImageDrawable) {
                        d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        d.start()
                    }
                    val maxH = (resources.displayMetrics.heightPixels * 0.6f).toInt()
                    val h = (widthPx * ratio).toInt().coerceIn(dp(40), maxH)
                    showPopup(iv, h, caption(), Prefs.int(this, "duration") * 1000L)
                }
            } catch (_: Throwable) {
            }
        }
    }

    private fun spawnVideo(f: File) {
        val widthPx = popupWidth()
        var ratio = 0.5625f
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(f.absolutePath)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloatOrNull()
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloatOrNull()
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (w != null && h != null && w > 0 && h > 0) {
                ratio = if (rot == 90 || rot == 270) w / h else h / w
            }
        } catch (_: Exception) {
        }
        val maxH = (resources.displayMetrics.heightPixels * 0.6f).toInt()
        val vh = (widthPx * ratio).toInt().coerceIn(dp(40), maxH)
        val vv = VideoView(this)
        vv.setVideoPath(f.absolutePath)
        vv.setOnPreparedListener { mp ->
            mp.isLooping = false
            vv.start()
        }
        val root = showPopup(vv, vh, caption(), 180_000L) ?: return
        vv.setOnCompletionListener { dismiss(root) }
        vv.setOnErrorListener { _, _, _ -> dismiss(root); true }
    }

    private fun playAudio(f: File) {
        if (players.isNotEmpty()) return
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { players.remove(it); it.release() }
            mp.setOnErrorListener { p, _, _ -> players.remove(p); p.release(); true }
            players += mp
            mp.prepareAsync()
        } catch (_: Exception) {
            players.remove(mp)
            mp.release()
        }
    }

    // ---------- Fenêtres flottantes ----------

    private fun showPopup(media: View?, mediaH: Int, caption: String?, durationMs: Long): View? {
        val widthPx = popupWidth()
        val root = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setBackgroundColor(0xEE000000.toInt())

        if (media != null) col.addView(media, LinearLayout.LayoutParams(widthPx, mediaH))
        if (caption != null) {
            val tv = TextView(this)
            tv.text = caption
            tv.setTextColor(Color.WHITE)
            tv.textSize = if (media == null) 22f else 15f
            tv.gravity = Gravity.CENTER
            tv.setPadding(dp(10), dp(10), dp(10), dp(10))
            col.addView(tv, LinearLayout.LayoutParams(widthPx, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        root.addView(col, FrameLayout.LayoutParams(widthPx, FrameLayout.LayoutParams.WRAP_CONTENT))

        val close = TextView(this)
        close.text = "✕"
        close.textSize = 18f
        close.setTextColor(Color.WHITE)
        close.setBackgroundColor(0xAA000000.toInt())
        close.setPadding(dp(12), dp(6), dp(12), dp(6))
        close.setOnClickListener { dismiss(root) }
        root.addView(
            close,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
        )
        root.alpha = Prefs.int(this, "opacity") / 100f

        val dm = resources.displayMetrics
        val estH = mediaH + if (caption != null) dp(90) else dp(20)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Random.nextInt(0, (dm.widthPixels - widthPx).coerceAtLeast(1))
        lp.y = Random.nextInt(0, (dm.heightPixels - estH).coerceAtLeast(1))

        try {
            wm.addView(root, lp)
        } catch (_: Exception) {
            return null
        }
        popups += root
        if (durationMs > 0) {
            val r = Runnable { dismiss(root) }
            root.tag = r
            handler.postDelayed(r, durationMs)
        }
        return root
    }

    private fun findVideo(v: View): VideoView? {
        if (v is VideoView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findVideo(v.getChildAt(i))?.let { return it }
        return null
    }

    private fun dismiss(v: View) {
        (v.tag as? Runnable)?.let { handler.removeCallbacks(it) }
        try {
            findVideo(v)?.stopPlayback()
        } catch (_: Exception) {
        }
        if (popups.remove(v)) {
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    private fun clearAll() {
        popups.toList().forEach { dismiss(it) }
        players.toList().forEach {
            try {
                it.release()
            } catch (_: Exception) {
            }
        }
        players.clear()
    }
}
