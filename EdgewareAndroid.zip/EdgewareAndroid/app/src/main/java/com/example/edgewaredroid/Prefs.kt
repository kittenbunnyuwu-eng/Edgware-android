package com.example.edgewaredroid

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val intDefaults = mapOf(
        "interval" to 10, "duration" to 8, "max" to 3, "size" to 50, "opacity" to 100
    )
    private val boolDefaults = mapOf(
        "img" to true, "vid" to true, "aud" to true, "cap" to true, "txt" to false
    )

    fun int(c: Context, key: String): Int = p(c).getInt(key, intDefaults[key] ?: 0)
    fun setInt(c: Context, key: String, v: Int) = p(c).edit().putInt(key, v).apply()

    fun bool(c: Context, key: String): Boolean = p(c).getBoolean(key, boolDefaults[key] ?: false)
    fun setBool(c: Context, key: String, v: Boolean) = p(c).edit().putBoolean(key, v).apply()

    fun pack(c: Context): String? = p(c).getString("pack", null)
    fun setPack(c: Context, name: String) = p(c).edit().putString("pack", name).apply()
}
