package com.example.edgewaredroid

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

class Pack(val name: String, val dir: File) {
    fun files(sub: String): List<File> =
        File(dir, sub).listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()

    val captions: List<String>
        get() = File(dir, "captions.txt").takeIf { it.exists() }
            ?.readLines()?.filter { it.isNotBlank() } ?: emptyList()
}

/**
 * Importe un pack ZIP (format Edgeware++ ou simple dossier zippé).
 * Le contenu est classé par extension, peu importe l'arborescence du ZIP :
 *   images -> img/, vidéos -> vid/, audio -> aud/, légendes -> captions.txt
 */
object PackManager {
    private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
    private val VID = setOf("mp4", "webm", "mkv", "3gp", "m4v", "mov")
    private val AUD = setOf("mp3", "ogg", "wav", "m4a", "aac", "flac", "opus")

    private fun root(c: Context) = File(c.filesDir, "packs").apply { mkdirs() }

    fun list(c: Context): List<String> =
        root(c).listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()

    fun load(c: Context, name: String): Pack? {
        val d = File(root(c), name)
        return if (d.isDirectory) Pack(name, d) else null
    }

    fun delete(c: Context, name: String) {
        File(root(c), name).deleteRecursively()
    }

    private fun displayName(c: Context, uri: Uri): String {
        var n: String? = null
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) n = it.getString(0)
        }
        return (n ?: "pack").removeSuffix(".zip").removeSuffix(".ZIP")
    }

    private fun safe(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(80)

    fun import(c: Context, uri: Uri): String {
        var name = safe(displayName(c, uri)).ifBlank { "pack" }
        var k = 2
        while (File(root(c), name).exists()) name = safe(displayName(c, uri)) + "-" + k++
        val dir = File(root(c), name)
        listOf("img", "vid", "aud").forEach { File(dir, it).mkdirs() }

        val captions = LinkedHashSet<String>()
        var media = 0
        try {
            val input = c.contentResolver.openInputStream(uri) ?: error("Fichier illisible")
            ZipInputStream(BufferedInputStream(input)).use { zin ->
                var i = 0
                var e = zin.nextEntry
                while (e != null) {
                    val path = e.name
                    val lower = path.lowercase()
                    val base = path.substringAfterLast('/')
                    if (!e.isDirectory && !lower.startsWith("__macosx") && !base.startsWith("._")) {
                        val ext = base.substringAfterLast('.', "").lowercase()
                        // On n'utilise jamais le chemin du ZIP pour écrire : pas de zip-slip.
                        when {
                            ext in IMG -> { copy(zin, File(dir, "img/${i++}_${safe(base)}")); media++ }
                            ext in VID -> { copy(zin, File(dir, "vid/${i++}_${safe(base)}")); media++ }
                            ext in AUD -> { copy(zin, File(dir, "aud/${i++}_${safe(base)}")); media++ }
                            ext == "json" && lower.contains("caption") ->
                                captions += parseCaptions(zin.readBytes().toString(Charsets.UTF_8))
                            ext == "txt" && lower.contains("caption") ->
                                captions += zin.readBytes().toString(Charsets.UTF_8)
                                    .lines().map { it.trim() }.filter { it.isNotEmpty() }
                        }
                    }
                    zin.closeEntry()
                    e = zin.nextEntry
                }
            }
            if (media == 0 && captions.isEmpty()) error("Aucun média trouvé dans ce ZIP")
            File(dir, "captions.txt").writeText(captions.joinToString("\n"))
        } catch (t: Throwable) {
            dir.deleteRecursively()
            throw t
        }
        return name
    }

    private fun copy(from: InputStream, to: File) {
        to.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = from.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
            }
        }
    }

    /** Récupère toutes les chaînes contenues dans des tableaux du JSON (format souple). */
    private fun parseCaptions(text: String): List<String> {
        val out = ArrayList<String>()
        fun walk(v: Any?, key: String?) {
            when (v) {
                is JSONObject -> v.keys().forEach { k -> if (k != "prefix_settings") walk(v.get(k), k) }
                is JSONArray -> for (i in 0 until v.length()) {
                    val x = v.get(i)
                    if (x is String) {
                        val s = x.trim()
                        if (s.isNotEmpty() && s.length <= 300) out += s
                    } else walk(x, key)
                }
            }
        }
        try {
            val t = text.trim()
            if (t.startsWith("[")) walk(JSONArray(t), null) else walk(JSONObject(t), null)
        } catch (_: Exception) {
        }
        return out
    }
}
