package com.example.edgewaredroid

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var spinner: Spinner
    private lateinit var info: TextView
    private lateinit var btnToggle: Button
    private lateinit var btnImport: Button
    private lateinit var status: TextView
    private var names: List<String> = emptyList()

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importPack(uri)
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startOverlay() }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.spinnerPack)
        info = findViewById(R.id.txtPackInfo)
        btnToggle = findViewById(R.id.btnToggle)
        btnImport = findViewById(R.id.btnImport)
        status = findViewById(R.id.txtStatus)

        buildSettings()

        btnImport.setOnClickListener { importLauncher.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnDelete).setOnClickListener { confirmDelete() }
        btnToggle.setOnClickListener { toggle() }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                names.getOrNull(pos)?.let { Prefs.setPack(this@MainActivity, it) }
                updateInfo()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        refreshPacks(null)
    }

    override fun onResume() {
        super.onResume()
        updateToggle()
    }

    // ---------- Packs ----------

    private fun refreshPacks(select: String?) {
        names = PackManager.list(this)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val wanted = select ?: Prefs.pack(this)
        val idx = names.indexOf(wanted)
        if (names.isNotEmpty()) spinner.setSelection(if (idx >= 0) idx else 0)
        updateInfo()
    }

    private fun updateInfo() {
        val pack = names.getOrNull(spinner.selectedItemPosition)?.let { PackManager.load(this, it) }
        info.text = if (pack == null) {
            "Aucun pack. Importe un ZIP pour commencer."
        } else {
            "${pack.files("img").size} images · ${pack.files("vid").size} vidéos · " +
                "${pack.files("aud").size} audios · ${pack.captions.size} légendes"
        }
    }

    private fun importPack(uri: Uri) {
        btnImport.isEnabled = false
        Toast.makeText(this, "Import en cours…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val name = PackManager.import(this, uri)
                runOnUiThread {
                    refreshPacks(name)
                    Toast.makeText(this, "Pack « $name » importé", Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "Échec : ${t.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                runOnUiThread { btnImport.isEnabled = true }
            }
        }.start()
    }

    private fun confirmDelete() {
        val name = names.getOrNull(spinner.selectedItemPosition) ?: return
        AlertDialog.Builder(this)
            .setMessage("Supprimer le pack « $name » ?")
            .setPositiveButton("Supprimer") { _, _ ->
                PackManager.delete(this, name)
                refreshPacks(null)
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------- Démarrage / arrêt ----------

    private fun toggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            btnToggle.postDelayed({ updateToggle() }, 500)
            return
        }
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorise « Afficher par-dessus les autres applis »", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (names.isEmpty()) {
            Toast.makeText(this, "Importe d'abord un pack", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startOverlay()
    }

    private fun startOverlay() {
        ContextCompat.startForegroundService(
            this, Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_START)
        )
        btnToggle.postDelayed({ updateToggle() }, 500)
    }

    private fun updateToggle() {
        val run = OverlayService.running
        btnToggle.text = if (run) "Arrêter" else "Démarrer"
        status.text = if (run) "En cours — chaque popup a un ✕, et la notification a « Arrêter »."
        else if (!AndroidSettings.canDrawOverlays(this)) "Permission d'affichage par-dessus les autres applis requise."
        else "Arrêté."
    }

    // ---------- Réglages ----------

    private fun buildSettings() {
        val box = findViewById<LinearLayout>(R.id.settingsContainer)
        addSeek(box, "Intervalle entre popups", "interval", 1, 300, " s")
        addSeek(box, "Durée d'affichage", "duration", 1, 60, " s")
        addSeek(box, "Popups simultanés max", "max", 1, 10, "")
        addSeek(box, "Taille (% de la largeur)", "size", 20, 95, " %")
        addSeek(box, "Opacité", "opacity", 30, 100, " %")
        addCheck(box, "Images (GIF/WebP animés inclus)", "img")
        addCheck(box, "Vidéos", "vid")
        addCheck(box, "Audio", "aud")
        addCheck(box, "Légendes sous les médias", "cap")
        addCheck(box, "Popups texte seul (légendes)", "txt")
    }

    private fun addSeek(parent: LinearLayout, label: String, key: String, min: Int, max: Int, unit: String) {
        val tv = TextView(this)
        val sb = SeekBar(this)
        val cur = Prefs.int(this, key).coerceIn(min, max)
        sb.max = max - min
        sb.progress = cur - min
        tv.text = "$label : $cur$unit"
        tv.setPadding(0, dp(12), 0, 0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label : ${p + min}$unit"
                if (fromUser) Prefs.setInt(this@MainActivity, key, p + min)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun addCheck(parent: LinearLayout, label: String, key: String) {
        val cb = CheckBox(this)
        cb.text = label
        cb.isChecked = Prefs.bool(this, key)
        cb.setOnCheckedChangeListener { _, checked -> Prefs.setBool(this, key, checked) }
        parent.addView(cb)
    }
}
