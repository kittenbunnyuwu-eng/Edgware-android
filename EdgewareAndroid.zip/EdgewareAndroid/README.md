# Edgeware Android (non officiel)

App Android inspirée d'Edgeware++ : affiche des popups (images, GIF/WebP animés,
vidéos, audio, légendes) par-dessus tes autres applis, à partir de packs importés.
**18+, usage personnel.** Aucun contenu n'est fourni : tu importes tes propres packs.

## Compiler
1. Ouvre le dossier dans **Android Studio** (Hedgehog ou plus récent, JDK 17).
2. Laisse la synchro Gradle se faire (il télécharge Gradle 8.7 tout seul).
3. Branche ton téléphone (débogage USB) puis ▶ Run,
   ou **Build > Build APK(s)** pour obtenir un APK à installer.

## Utiliser
1. **Importer un pack (ZIP)** : choisis ton ZIP dans le sélecteur de fichiers.
2. Règle l'intervalle, la taille, l'opacité, les types de contenu.
3. **Démarrer** : accepte « Afficher par-dessus les autres applis » puis les notifications.

Les réglages s'appliquent en direct pendant que ça tourne.

## Format de pack
Le ZIP est lu par extensions, quelle que soit l'arborescence (les packs Edgeware++ passent) :
- images : jpg, png, gif, webp, bmp
- vidéos : mp4, webm, mkv, 3gp
- audio : mp3, ogg, wav, m4a, aac, flac, opus
- légendes : un `captions.json` (toutes les listes de textes sont lues) ou un `captions.txt` (une par ligne)

Les options propres à Edgeware PC (wallpaper, panic, hypno, etc.) ne sont pas gérées.

## Sécurité
- Chaque popup a un **✕**, la notification a **Arrêter** / **Tout fermer**.
- Pas de mode verrouillé : tu peux toujours tout couper.
